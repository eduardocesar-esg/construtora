# Fase 4 - Execucao Controlada do Setup do Piloto

## Objetivo

Executar o setup controlado do piloto PMO Agentico Codex Slack para uma construtora de medio porte, preparando o repositorio, os dados minimos da primeira obra, os logs operacionais e o gate de revisao humana antes do uso executivo.

## Contexto

O piloto tera duracao de 3 a 6 meses e comecara com 1 obra piloto. O foco inicial e validar a operacao assistida antes de ampliar para outras obras.

## Escopo Inicial da Execucao

1. Status Report Executivo de Obras.
2. Matriz de Riscos de Obras.
3. Action Log.
4. Decision Log.
5. Evidence Log.
6. Agent Run Log.
7. Output Review Log.
8. Dashboard de sucesso do piloto.
9. Slack ou Teams Cockpit.
10. Revisao humana obrigatoria antes de publicacao executiva.

## Estrutura Base

```text
prompts/
agents/
registers/
schemas/
data-contracts/
templates/
slack/
dashboards/
governance/
reports/
codex/
docs/
```

## Sequencia Controlada

1. Confirmar papeis e obra piloto.
2. Confirmar repositorio GitHub.
3. Importar prompts no Codex.
4. Rodar PRM-BOOTSTRAP-001.
5. Rodar PRM-REGFACTORY-001.
6. Rodar PRM-HITLQA-001.
7. Coletar dados minimos da obra.
8. Rodar diagnostico e status report.
9. Rodar riscos, acoes, decisoes e evidencias.
10. Fazer revisao humana e preparar primeiro ciclo semanal.

## Gates de Seguranca

Antes de publicar qualquer output, validar:

- Separacao entre fato, hipotese e recomendacao.
- Evidencias indicadas.
- Lacunas declaradas.
- Ausencia de dado sensivel indevido.
- Decisoes criticas escaladas para sponsor.
- Impacto contratual escalado para juridico.
- Alteracao de prazo, custo ou baseline com aprovacao formal.
- Acoes concluidas com evidencia.
- Revisao HITL registrada.
- Aprovacao para publicacao.

