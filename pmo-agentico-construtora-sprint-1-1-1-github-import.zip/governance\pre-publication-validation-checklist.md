# Checklist de Validacao Antes de Publicar Qualquer Output

## Objetivo

Bloquear publicacao de outputs que nao tenham evidencias, revisao humana ou aprovacao adequada.

## Checklist

| Pergunta | Criterio | Resultado | Observacao |
|---|---|---|---|
| O output separa fato, hipotese e recomendacao? | Obrigatorio |  |  |
| As evidencias foram indicadas? | Obrigatorio |  |  |
| Existem lacunas declaradas? | Obrigatorio |  |  |
| Ha risco de dado sensivel? | Bloqueante |  |  |
| Ha decisao critica? | Requer sponsor |  |  |
| Ha impacto contratual? | Requer juridico |  |  |
| Ha alteracao de prazo/custo/baseline? | Requer aprovacao formal |  |  |
| Ha acao marcada como concluida sem evidencia? | Bloqueante |  |  |
| O output foi revisado no HITL? | Obrigatorio |  |  |
| Esta aprovado para publicacao? | Obrigatorio |  |  |

## Resultado

Status de publicacao: Aprovado / Aprovado com ajustes / Bloqueado  
Revisor:  
Data:  
Ajustes obrigatorios:  
Evidencia da aprovacao:  

